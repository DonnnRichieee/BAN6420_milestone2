PCA and Logistic Regression on Breast Cancer Dataset
===================================================

Project Description
-------------------
This project demonstrates the application of Principal Component Analysis (PCA) to identify essential variables from the breast cancer dataset available in sklearn.datasets. It also implements logistic regression to predict the target variable based on the reduced PCA components.

Requirements
------------
- Python 
- Preferably Jupyter notebook
- Libraries: pandas, numpy, seaborn, matplotlib, scikit-learn

Installation
------------
1. Clone the repository or download the zip file.
2. Navigate to the project directory.
3. Install the required libraries using pip:
   ```bash
   pip install pandas numpy seaborn matplotlib scikit-learn

Usage
------------
1. Load the cancer dataset from sklearn.datasets.
2. Standardize the dataset using StandardScaler.
3. Apply PCA to reduce the dataset to 2 components.
4. Implement logistic regression to predict the target variable using the PCA components.
5. Evaluate the model performance using classification report and confusion matrix.

Implementation Steps
------------
Import Required Libraries

    -import pandas as pd
    -import numpy as np
    -import seaborn as sns
    -import matplotlib.pyplot as plt
    -from sklearn.datasets import load_breast_cancer
    -from sklearn.preprocessing import StandardScaler
    -from sklearn.decomposition import PCA
    -from sklearn.model_selection import train_test_split
    -from sklearn.linear_model import LogisticRegression
    -from sklearn.metrics import classification_report, confusion_matrix


Load and Explore Dataset:

    cancer = load_breast_cancer()
    df = pd.DataFrame(cancer['data'], columns=cancer['feature_names'])
    df.info()
    df.describe()


Standardize the Data:

    scaler = StandardScaler()
    scaled_data = scaler.fit_transform(df)
    Apply PCA

Apply PCA:

    pca = PCA(n_components=2)
    pca_components = pca.fit_transform(scaled_data)
    pca_df = pd.DataFrame(pca_components, columns=['PCA1', 'PCA2'])

Logistic Regression for Prediction:

    target = pd.Series(cancer['target'], name='target')
    pca_df = pd.concat([pca_df, target], axis=1)
    X = pca_df[['PCA1', 'PCA2']]
    y = pca_df['target']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=101)
    logmodel = LogisticRegression()
    logmodel.fit(X_train, y_train)
    predictions = logmodel.predict(X_test)
    print(classification_report(y_test, predictions))
    print(confusion_matrix(y_test, predictions))

Results
------------
Classification Report:

                      precision    recall  f1-score   support
                   0       0.93      0.95      0.94        66
                   1       0.97      0.95      0.96       105
            accuracy                           0.95       171
           macro avg       0.95      0.95      0.95       171
        weighted avg       0.95      0.95      0.95       171

Confusion Matrix:
    array([[ 63,   3],
           [  5, 100]], dtype=int64)


Interpretation
------------

1. High Accuracy: The model correctly predicts the class of 95% of the instances, demonstrating high overall performance.

2. Benign Tumor Predictions: The model identifies benign tumors with 93% precision and 95% recall, meaning it correctly identifies most benign tumors and rarely misclassifies them as malignant.

3. Malignant Tumor Predictions: The model identifies malignant tumors with 97% precision and 95% recall, indicating it accurately identifies malignant tumors and rarely misclassifies them as benign.

4. Confusion Matrix: The confusion matrix shows high true positives and true negatives, with low false positives and false negatives, indicating a robust model performance.

Conclusion
------------
    The PCA and logistic regression model effectively reduces dimensionality and predicts the target variable with high accuracy. This approach can be utilized for identifying essential variables and building predictive models in similar datasets.